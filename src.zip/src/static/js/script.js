document.addEventListener('DOMContentLoaded', () => {
    const dataBox = document.querySelector('.data-box');
    const resultBox = document.querySelector('.result-box');
    const videoBtn = document.getElementById('upload-video');
    const imageBtn = document.getElementById('upload-image');
    const cameraBtn = document.getElementById('start-camera');

    function createFileInput(acceptType) {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = acceptType;
        input.style.display = 'none';
        document.body.appendChild(input);

        input.addEventListener('change', async () => {
            const file = input.files[0];
            if (!file) return;

            const formData = new FormData();
            formData.append('file', file);
            formData.append('model', 'yolov8n');
            formData.append('confidence', '0.5');

            dataBox.innerHTML = 'Đang xử lý dữ liệu...';
            resultBox.innerHTML = 'Đang phân loại...';

            try {
                const response = await fetch('/upload', {
                    method: 'POST',
                    body: formData
                });

                if (response.ok) {
                    const resultUrl = await response.text();
                    if (file.type.startsWith('image/')) {
                        dataBox.innerHTML = `<img src="${URL.createObjectURL(file)}" class="img-fluid rounded">`;
                        resultBox.innerHTML = `<img src="${resultUrl}" class="img-fluid rounded">`;
                    } else {
                        dataBox.innerHTML = `<video src="${URL.createObjectURL(file)}" class="img-fluid rounded" controls></video>`;
                        resultBox.innerHTML = `<video src="${resultUrl}" class="img-fluid rounded" controls autoplay></video>`;
                    }
                } else {
                    const error = await response.text();
                    dataBox.innerHTML = 'Lỗi khi tải dữ liệu';
                    resultBox.innerHTML = error;
                }
            } catch (err) {
                dataBox.innerHTML = 'Lỗi hệ thống';
                resultBox.innerHTML = err.message;
            }

            document.body.removeChild(input);
        });

        input.click();
    }

    videoBtn.addEventListener('click', () => createFileInput('video/*'));
    imageBtn.addEventListener('click', () => createFileInput('image/*'));

    cameraBtn.addEventListener('click', () => {
        dataBox.innerHTML = 'Đang bật camera...';
        resultBox.innerHTML = `
            <img src="/webcam_feed?model=yolov8n&confidence=0.5" class="img-fluid rounded">
        `;
    });
});
